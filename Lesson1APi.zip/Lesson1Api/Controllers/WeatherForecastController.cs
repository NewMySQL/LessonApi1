﻿using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Mvc;

namespace Lesson1Api.Controllers
{
    [ApiController]
    [Route("api/[controller]/[action]")]
    public class WeatherForecastController : ControllerBase
    {
        private static readonly string[] Summaries = new[]
        {
        "Freezing", "Bracing", "Chilly", "Cool", "Mild", "Warm", "Balmy", "Hot", "Sweltering", "Scorching"
    };

        private readonly ILogger<WeatherForecastController> _logger;

        public WeatherForecastController(ILogger<WeatherForecastController> logger)
        {
            _logger = logger;
        }

        [HttpGet("/Test")]
        public IActionResult Get()
        {
            var weatherCast = Enumerable.Range(1, 5).Select(index => new WeatherForecast
                {
                    Date = DateTime.Now.AddDays(index),
                    TemperatureC = Random.Shared.Next(-20, 55),
                    Summary = Summaries[Random.Shared.Next(Summaries.Length)]
                })
                .ToArray();

            return Ok(weatherCast);
        }

        [HttpPost("{id}")]
        public IActionResult Get2(
            [Required, FromRoute] int? id,
            [FromQuery] string name,
            [FromHeader] string? lang,
            [FromForm] string animalname, [FromForm] int animalage)
        {
            switch (lang)
            {
                case "en":
                    return Ok($"Hello {name}, id - {id}, animal - {animalname}:{animalage}");

                case "ru":
                default:
                    return Ok($"Привет {name}, id - {id}, animal - {animalname}:{animalage}");
            }
        }
    }

    public class Animal
    {
        public string Name { get; set; }
        public int Age { get; set; }
    }
}